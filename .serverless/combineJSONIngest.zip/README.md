# takeon-ingest-combine-json
A lambda function, deployed serverlessly to extract JSON data from S3 bucket and batch into into 50 files at a time to send to BL API and notification queue
