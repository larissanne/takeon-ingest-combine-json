import requests

request = requests.get('http://a8f1926bdf1c111e9a5a70a6b6f05390-484c09026fdfe776.elb.eu-west-2.amazonaws.com:8088/response/saveBatchResponses/')
print(request.text)

def callingestapi(queue_url, msg_body):
    try:
        
        except ClientError as e:
        print("Error in calling api: " + e)
        # logging.error(e)
        return None
    return msg